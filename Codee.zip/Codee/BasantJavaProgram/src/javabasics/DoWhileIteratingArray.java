package javabasics;

public class DoWhileIteratingArray {

	public static void main(String[] args) {
		
		int[] arr = {23,45,6,90,6};
		int i = 0;
		
		do {
			System.out.println(arr[i]);
			i++;
		}while(i<arr.length);

	}
}
