package com.arrays;

import java.io.*;

public class Arr2 {
public static void main(String args[]) throws IOException{
	float Avg, Tot = 0;
   //To accept data from keyboard
   BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
   int n = Integer.parseInt(br.readLine());
   // int sub[] = new int[n];
    int marks[] = new int[n];
 
 //Enter marks in different subjects
   for(int i =0;i<n;i++){
	 System.out.print("Enter the Marks:");
	 marks[i] = Integer.parseInt(br.readLine());
	// System.out.println("Marks in "+sub[i+1]+" is "+marks[i]);
}
 
 //Calculate the marks
 for(int i=0;i<n;i++){
         Tot = Tot + marks[i] ;
  }
 
 //Calculate Average
   Avg = Tot/n ;
 //Average marks
   System.out.println("Average marks is "+Avg);
 }
}
