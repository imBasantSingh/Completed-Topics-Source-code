package BasantJavaProgram.com.JavaBasics.inputoutput.scannerio;

// Java program to read data of various types using Scanner class.
        /*
         *    Strings : ob.nextLine();
         *    Character : ob.next().charAt(0);
         *    Integer : ob.nextInt();
         *    Long : ob.nextLong();
         *    Double : ob.nextDouble();
         *
         * */

import java.util.Scanner;

public class ProblemwithNextLine {
    public static void main(String[] args) {
        // Declare the object and initialize with
        // predefined standard input object
        Scanner sc = new Scanner(System.in);

        // Character input
        System.out.println("Enter Sex: ");
        char gender = sc.next().charAt(0);

        /*
         * Put a Scanner.nextLine call after each Scanner.nextInt or Scanner.nextDouble to
         * consume rest of that line including newline
         * */
        sc.nextLine();

        // Strings input
        System.out.println("Enter Name: ");
        String name = sc.nextLine();


        // Print the values to check if input was correctly obtained.
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);

    }
}
