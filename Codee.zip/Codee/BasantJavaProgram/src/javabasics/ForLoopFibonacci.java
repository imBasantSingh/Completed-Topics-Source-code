package javabasics;

import java.util.Scanner;

public class ForLoopFibonacci {
	
	private static Scanner inpt = new Scanner(System.in);

	public static void main(String[] args) {
				
		System.out.println("Enter number of fibonacci series: ");
		int count = inpt.nextInt();
		int fibo1 = 0;
		int fibo2 = 1;
		int sumofFibos = 0;
		
		for(int i=1; i<=count;i++) {
			System.out.print(fibo1+" ");
			
			sumofFibos = fibo1 + fibo2;
			fibo1 = fibo2;
			fibo2 = sumofFibos ;
		}
			
	}

}
