package BasantJavaProgram.com.JavaFlowControl.selectionstatements;

public class IfThen {

    public static void main(String[] args) {

        boolean isAlien = false;
        if (isAlien == false) {
            System.out.println("It is not an alien!");
            System.out.println("And I am scared of aliens");
        }
    }
}
