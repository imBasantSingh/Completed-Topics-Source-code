package javabasics;

import java.util.Scanner;

public class AsciiToChar {
	
	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Enter ASCII number : ");
		int num = scan.nextInt();
		
		char ch = (char)num;
				
		 System.out.println("Character value of "+num +" is: " + ch);
	    
	}

}
