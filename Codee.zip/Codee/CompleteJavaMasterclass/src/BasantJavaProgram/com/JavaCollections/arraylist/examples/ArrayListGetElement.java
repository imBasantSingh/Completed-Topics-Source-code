package BasantJavaProgram.com.JavaCollections.arraylist.examples;

/*
 * Object get(int index):
		It returns the element present in the mentioned position in the arraylist.
		If the index mentioned in the argument is more then the size of arraylist ,then it throws Index Out of Bound 
		Exception
 * */

import java.util.ArrayList;

public class ArrayListGetElement {
    public static void main(String args[]) {
        ArrayList<Integer> aList = new ArrayList<Integer>(5);
        // use add() method to add elements in the list
        aList.add(7);
        aList.add(11);
        aList.add(13);
        System.out.println("Array List Number = " + aList);
        // element at 2nd postion
        int value = aList.get(2);
        System.out.println("Element Retrieved at index 2 i.e. 3rd position = " + value);
    }
}





