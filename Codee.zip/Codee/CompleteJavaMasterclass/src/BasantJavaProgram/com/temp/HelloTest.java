package BasantJavaProgram.com.temp;
public class HelloTest{

    public static void main(String args[]){

        System.out.println("Hello World");
    }

}
