package BasantJavaProgram.com.JavaClassObjects;

public class PersonDemoMain {
    public static void main(String args[]){
        PersonDemo Basant = new PersonDemo();
        Basant.setName("Basant Singh");
        Basant.setAge(30);

        System.out.println(Basant.getName());
        System.out.println(Basant.getAge());
    }
}
