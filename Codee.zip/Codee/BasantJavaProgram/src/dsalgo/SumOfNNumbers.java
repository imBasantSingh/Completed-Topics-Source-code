package dsalgo;

import java.util.Scanner;

public class SumOfNNumbers {
	public static long sum = 0;
	public static long count = 0;
	
	public static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Enter number of Natural number: ");
		
		long n = input.nextLong();
		
		for(int i = 1; i <= n; i++) {
			sum+=i;
		}
		
		System.out.println("Sum of "+n+" Natural number: "+sum);   
	}
}
