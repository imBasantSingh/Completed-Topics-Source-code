package Algorithms.GFG;

public class SolutionProb4 {
    public static void main(String args[]) {
        //int A[]={3, 2, -6, 4, 0};
        //int A[]={3, 2, 6, 4, 0}, N = 5;
        int A[] = {-4, -8, -3, -2, -4, -10};

        System.out.println("The absolute sum of min abs slice is " + solution(A));
    }


    public static int solution(int[] A) {
        int min = A[0];
        int absMin = A[0];
        int minTemp = A[0];
        int i;
        for (i = 0; i < A.length; i++) {
            absMin = Math.min(Math.abs(A[i]), Math.abs(min + A[i]));
            min = Math.min(A[i], min + A[i]);
            minTemp = Math.min(Math.abs(minTemp), absMin);
        }
        return minTemp;
    }
}
