package javabasics;

import java.util.Scanner;

//Java program to read data of various types using Scanner class.
/*
 *    Strings : ob.nextLine();
 *    Character : ob.next().charAt(0);
 *    Integer : ob.nextInt();
 *    Long : ob.nextLong();
 *    Double : ob.nextDouble();
 *
 * */

public class SwitchCaseCheckVowel {

	public static void main(String[] args) {
		
		boolean isVowel=false;;
		Scanner inpt=new Scanner(System.in);
		System.out.println("Enter a character : ");
		char ch=inpt.next().charAt(0); 
		inpt.close();
		switch(ch)
		{
		   case 'a' :
		   case 'e' :
	       case 'i' :
		   case 'o' :
		   case 'u' :
		   case 'A' :
		   case 'E' :
		   case 'I' :
		   case 'O' :
		   case 'U' :
			   isVowel = true;
		}
		if(isVowel == true) {
		   System.out.println(ch+" is  a Vowel");
		}
		else {
		   if((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z'))
			System.out.println(ch+" is a Consonant");
		   else
			System.out.println("Input is not an alphabet");		
	        }

	}

}
