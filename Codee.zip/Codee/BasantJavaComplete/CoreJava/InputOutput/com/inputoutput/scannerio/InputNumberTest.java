package com.inputoutput.scannerio;

import java.util.Scanner;

public class InputNumberTest {
	
	public static void main(String args[]) {
		
	int num;
	
	Scanner scanner = new Scanner(System.in);
	
	System.out.println("Enter the number");
	
	num = scanner.nextInt();
	
	scanner.close();
	
	System.out.println("Entered Number is  "+num);
}
	
}
