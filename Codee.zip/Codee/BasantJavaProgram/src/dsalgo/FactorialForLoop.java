package dsalgo;

import java.util.Scanner;

public class FactorialForLoop {
	public static long fact = 1;
	
	
	public static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Enter number of Natural number: ");
		
		long n = input.nextLong();
		
		for(int i = 1; i <= n; i++) {
			fact*=i;
		}
		
		System.out.println("Factorial of "+n+" Natural number: "+fact);   
	}
}
