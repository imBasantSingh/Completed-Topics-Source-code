package BasantJavaProgram.com.QuizOutput;

public class Output1DoWhile {
    public static void main(String[] args)
    {
        int i = 0, j = 9;
        do {
            i++;
            System.out.println("Print 1: " + i + "" + j);
            if (j-- < i++) {
                System.out.println("Print 2: " +i + "" + j);
                break;
            }
        } while (i < 5);
        System.out.println("Print 3: " +i + "" + j);
    }

  /*  In the above program, we have to specially take care about the break statement.
    The execution of the program is going as usual as the control flow of do-while loop but whenever
    compiler encountered break statement its control comes out from the loop.*/
}
