package BasantJavaProgram.com.temp;

import java.util.Map;
import java.util.TreeMap;

class CoreJavaCollections014 {
    //static int t;

    public static void main(String args[]) {
        TreeMap tree = new TreeMap();
        tree.put("aa", "bb");
        tree.put("cc", "dd");
        tree.put("ee", "ff");
        tree.put("gg", "hh");
        Map map = tree.tailMap("ee");
        System.out.println(map);

    }
}
