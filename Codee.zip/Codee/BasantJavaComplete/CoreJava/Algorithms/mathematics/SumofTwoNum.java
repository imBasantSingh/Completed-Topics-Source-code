package mathematics;

import java.util.Scanner;

public class SumofTwoNum {

	public static void main(String[] args) {
		
		//Declare variable
		int num1,num2;
		int sum = 0;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter first number: ");
		num1 = input.nextInt();
		
		System.out.println("Enter Second number: ");
		num2 = input.nextInt();
		
		sum = num1 + num2;
		
		System.out.println("Sum of "+num1+" and "+num2+ " is "+sum);

	}

}
