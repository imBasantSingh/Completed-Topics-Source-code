package dsalgo;

import java.util.Scanner;

public class SumOfFirstNNumber {
	public static long sum = 0;
		
	public static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Enter number of Natural number: ");
		
		long n = input.nextLong();
		
		sum = n*(n+1)/2;
		
		/*
		 * int i = 1;
		 * 
		 * while(i <=n){ sum+=i; i++; }
		 */
		
		System.out.println("Sum of "+n+" Natural number: "+sum);   
	}
}
