package dsalgo;

import java.util.Scanner;

public class FactorialWhile {
	public static long fact = 1;
		
	public static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Enter number of Natural number: ");
		
		long n = input.nextLong();
		
		int i = 1;
		 
		 while(i <=n){ 
			 fact*=i; 
			 i++; 
			 }
		 
		
		System.out.println("Factorial of "+n+" Natural number: "+fact);   
	}
}
