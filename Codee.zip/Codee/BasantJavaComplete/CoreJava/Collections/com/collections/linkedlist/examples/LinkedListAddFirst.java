package com.collections.linkedlist.examples;

/*
 * void addFirst(Object o):
		This method add the specified element at the first position
 * */

import java.util.LinkedList;

public class LinkedListAddFirst {
	public static void main(String[] args) {
		LinkedList<String> llist = new LinkedList<String>();
		llist.add("Hi");
		llist.add("I");
		llist.add("Love");
		llist.add("java");
		System.out.println("Linked List:" + llist);
		// add a new element at first position
		llist.addFirst("First");
		// print the new list
		System.out.println("LinkedList:" + llist);
		}
}