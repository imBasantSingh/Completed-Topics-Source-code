package javabasics;

import java.util.Scanner;

public class AreaOfTriangle {

private static Scanner inpt = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
	System.out.println("Enter the width of the Triangle:");
	double width = inpt.nextDouble();
	
	System.out.println("Enter the height of the Triangle:");
	double height = inpt.nextDouble();
	
	inpt.close();
	
	double area = (width * height)/2;
	
	System.out.println("Area of Triangle is: "+area);

	}
}
