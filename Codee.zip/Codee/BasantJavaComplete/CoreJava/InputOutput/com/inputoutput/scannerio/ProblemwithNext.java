package com.inputoutput.scannerio;

// Java program to read data of various types using Scanner class.
        /*
         *    String : ob.nextLine();
         *    Character : ob.next().charAt(0);
         *    Integer : ob.nextInt();
         *    Long : ob.nextLong();
         *    Double : ob.nextDouble();
         *
         * */

import java.util.Scanner;

public class ProblemwithNext {
    public static void main(String[] args) {
        // Declare the object and initialize with
        // predefined standard input object
        Scanner sc = new Scanner(System.in);
        
        /*
         * next() can read the input only till the space. It can't read two words separated by space. 
         * Also, next() places the cursor in the same line after reading the input. nextLine() reads
         * input including space between the words (that is, it reads till the end of line \n).
         * */
        
        
        // String input
        System.out.println("Enter Name: ");
        String name = sc.next();
        
        sc.nextLine();
        
        // String input
        System.out.println("Enter Name: ");
        String name1 = sc.nextLine();

      
        // Print the values to check if input was correctly obtained.
        System.out.println("Name: " + name);
        System.out.println("Name: " + name1);
       
    }
}
