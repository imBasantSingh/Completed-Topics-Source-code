package BasantJavaProgram.com.QuizOutput;

public class Output2ForLoop {
    public static void main (String [] args)
    {
        for (int k=0; k<20; k=k+2)
        {
            if (k % 3 == 1)
                System.out.print(k+ " ");
        }
    }
}
