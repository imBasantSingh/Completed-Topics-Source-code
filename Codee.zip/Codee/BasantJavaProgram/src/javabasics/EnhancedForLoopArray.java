package javabasics;

public class EnhancedForLoopArray {

	public static void main(String[] args) {
		
		int arr[] = {222, 21, 6, 5, 9, 101, 62};
		
		for(int i: arr) {
			
			System.out.println(i);
			
		}
		
		System.out.println("Array Length is: "+arr.length);

	}

}