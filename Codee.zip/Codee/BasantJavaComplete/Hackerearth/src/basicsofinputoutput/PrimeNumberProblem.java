package basicsofinputoutput;

import java.util.Scanner;

/*
You are given an integer N. You need to print the series of all prime numbers till N.

Input Format

The first and only line of the input contains a single integer N denoting the number till where you need to find the series of prime number.

Output Format

Print the desired output in single line separated by spaces.

Constraints

1<=N<=1000
*/

public class PrimeNumberProblem {

	public static void main(String[] args) {
		
		boolean isPrime=true;
		
		Scanner input= new Scanner(System.in);
		//capture the input in an integer
		int num=input.nextInt();
	    input.close();
	    
	    for(int j=2;j<=num; j++) {
	    isPrime=true;
	    
		for(int i=2;i<=j/2;i++)
		{
	       
		   if(j%i==0)
		   {
		      isPrime=false;
		      break;
		   }
		}
		//If isPrime is true then the number is prime else not
		if(isPrime)
		   System.out.print(j + " ");
		
	   }

	}

}
