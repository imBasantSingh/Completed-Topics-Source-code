package module1;



class Testc {
	
	public static void main (String[] args){
		int y[]= new int[2];
		int a;
		int[]b;
		b=y;
		System.out.println(b[2]);
	}
}




