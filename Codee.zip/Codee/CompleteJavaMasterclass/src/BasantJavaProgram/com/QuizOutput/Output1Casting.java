package BasantJavaProgram.com.QuizOutput;

public class Output1Casting {
    public static void main(String args[])
    {
        System.out.print(20+ 1.34f + "A" + "B");
    }

    /*
    * 20 and 1.34f will be added and then 21.34 will be concatenated with “A” and “B”, hence output will be 21.34AB.
    * */
}
