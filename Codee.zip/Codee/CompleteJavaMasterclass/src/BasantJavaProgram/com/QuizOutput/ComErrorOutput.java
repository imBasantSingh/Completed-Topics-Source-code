package BasantJavaProgram.com.QuizOutput;

public class ComErrorOutput {
    public static void main(String args[])
    {
        int t;
        // System.out.println(t); // Compilation Error:(7, 28) java: variable t might not have been initialized

        t = 20; // // Changing above to this or successful compilation 
        System.out.println(t);
    }
}
