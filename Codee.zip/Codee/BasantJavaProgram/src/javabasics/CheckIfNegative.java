package javabasics;

import java.util.Scanner;

public class CheckIfNegative {

private static Scanner st = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	System.out.println("Enter number: ");
	int number = st.nextInt();
	st.close();
	
	if(number < 0) {
	 System.out.println("Entered number "+ number + " is negative");
	}
	else if(number == 0){
		System.out.println("Entered number "+ number + " is Zero");
	}
	else System.out.println("Entered number "+ number + " is Positive");
	}

}
