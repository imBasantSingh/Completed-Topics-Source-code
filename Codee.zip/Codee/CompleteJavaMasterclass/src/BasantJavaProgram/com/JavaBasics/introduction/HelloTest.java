package BasantJavaProgram.com.JavaBasics.introduction;

public class HelloTest {

    public static void main(String args[]){
        System.out.println("Test String");
    }
}
