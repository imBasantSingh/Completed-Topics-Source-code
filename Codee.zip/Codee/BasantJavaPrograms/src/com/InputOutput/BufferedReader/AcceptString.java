/*Accepting a String*/
package com.InputOutput.BufferedReader;

import java.io.*;

public class AcceptString {
    public static void main(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //Ask for string and accept it
        System.out.println("Enter the string ");
        String str = br.readLine();

        //Display the string
        System.out.println("You have entered " + str);
    }
}
