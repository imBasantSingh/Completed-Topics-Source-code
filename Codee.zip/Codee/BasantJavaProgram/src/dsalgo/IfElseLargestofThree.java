package dsalgo;

import java.util.Scanner;

public class IfElseLargestofThree {
	
	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) 
    {
        int num1, num2, num3, result, temp;
        /* Scanner is used for getting user input. 
         * The nextInt() method of scanner reads the
         * integer entered by user.
         */
        System.out.println("Enter First Number:");
        num1 = scanner.nextInt();
        System.out.println("Enter Second Number:");
        num2 = scanner.nextInt();
        System.out.println("Enter Third Number:");
        num3 = scanner.nextInt();
        scanner.close();
       
        if(num1 > num2) {
        	if(num1 > num3) {
        	System.out.println("Largest number is: "+num1);
        	}
        	else System.out.println("Largest number is: "+num3);
        	}
        
        else if(num2 > num1){
        	 if(num2 > num3) {
        	System.out.println("Largest number is: "+num2);
    	}
    	else System.out.println("Largest number is: "+num3);
    	}
      }
}

