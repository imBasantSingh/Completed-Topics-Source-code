package BasantJavaProgram.com.JavaBasics.inputoutput.bufferedreader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AcceptEmpData {
    public static void main(String args[]) throws IOException {
        //Create a bufferedReader Object to accept data from keyword
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        //Ask for Employee Data and read it
        System.out.println("Enter the Employee ID : ");
        int id = Integer.parseInt(br.readLine());
        System.out.println("Enter the sex(M/F) : ");

        //Line will give unexpected output
        char ch1 = (char) br.read();
        System.out.println("Enter the name : ");
        String name = br.readLine();

        //Display Emp Data
        System.out.println("Employ ID is : " + id);
        System.out.println("Employ sex is : " + ch1);
        System.out.println("Employ Name is : " + name);
    }
}
