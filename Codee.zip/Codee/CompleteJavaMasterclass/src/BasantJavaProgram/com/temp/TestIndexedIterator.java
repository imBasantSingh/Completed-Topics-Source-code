package BasantJavaProgram.com.temp;

public class TestIndexedIterator {

    public static void main(String args[]) {

        System.out.println("" + 5 + 3);

    }
}


