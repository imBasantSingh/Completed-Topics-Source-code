package BasantJavaProgram.com.JavaCollections.arrays;


import java.util.Scanner;

public class ArrayOperations {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {


        int capacity = 5;
        int[] arrayIntergers1 = getIntegers(capacity);
        int[] arrayIntergers2 = getIntegers(capacity);
        int[] arrayAddition = arrayAdd(arrayIntergers1, arrayIntergers2);
        printArray(arrayAddition);
    }

    /* Get Integers*/
    public static int[] getIntegers(int capacity) {
        System.out.println("Enter " + capacity + " Integer values: ");
        int[] intArray = new int[capacity];
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = scanner.nextInt();
        }
        return intArray;
    }

    /*Array Addition*/
    public static int[] arrayAdd(int[] array1, int[] array2) {
        int[] arrayAddition = new int[array1.length];

        for (int i = 0; i < arrayAddition.length; i++) {
            arrayAddition[i] = array1[i] + array2[i];
        }
        return arrayAddition;
    }


    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println("Element " + i + " contents " + array[i]);
        }
    }

}

	


