package oops;

public class MoterBikeRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MoterBike ducati = new MoterBike(100);
		MoterBike honda = new MoterBike(50);
		MoterBike Spr = new MoterBike();
		
		ducati.start("Ducati");
		honda.start("Honda");
		Spr.start("Splender");
		
		/*
		 * ducati.speed = 100; honda.speed = 50;
		 * 
		 * System.out.println(ducati.speed); System.out.println(honda.speed);
		 */
		
		ducati.setSpeed(200);
		honda.setSpeed(100);
		
		System.out.println(ducati.getSpeed());
		System.out.println(honda.getSpeed());
		
		ducati.increaseSpped(20);
		honda.decreaseSpped(20);
		
		System.out.println(ducati.getSpeed());
		System.out.println(honda.getSpeed());
		System.out.println(Spr.getSpeed());

	}

}
