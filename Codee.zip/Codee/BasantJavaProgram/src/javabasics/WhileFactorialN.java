package javabasics;

import java.util.Scanner;

public class WhileFactorialN {
	
	private static Scanner inpt = new Scanner(System.in);

	public static void main(String[] args) {
		long fact =1;
		
		System.out.println("Enter number: ");
		int N = inpt.nextInt();
		
		int i =1;
		//Sum of N natural number
		while(i<=N) {
			fact*=i;
			i++;
		}
		
		System.out.println("Factorial of first "+N+" natural number is: "+fact);
	}
}
