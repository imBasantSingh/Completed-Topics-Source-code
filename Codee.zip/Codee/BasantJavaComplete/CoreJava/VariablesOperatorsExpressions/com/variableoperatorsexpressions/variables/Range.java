package com.variableoperatorsexpressions.variables;

public class Range {

    public static void main(String args[]) {

        //Integer has width of 32
        int myMinValue = -2_147_483_648;
        int myMaxValue = 2_147_483_647;
        int myTotal = (myMinValue + myMaxValue);
        System.out.println("myTotal value is " + myTotal);

    }
}
