package BasantJavaProgram.com.JavaFlowControl.Algorithms;

        /*
         * Program to compare two numbers.
         * */

import java.util.Scanner;

public class CompareTwoNumber {

    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Enter number1: ");
        int number1 = input.nextInt();

        System.out.println("Enter number2: ");
        int number2 = input.nextInt();
        compareNumber(number1, number2);
    }

    public static void compareNumber(int num1, int num2) {
        if (num1 > num2) {
            System.out.println(num1 + " is greater than " + num2);
        } else if (num1 < num2) {
            System.out.println(num2 + " is greater than " + num1);
        } else {
            System.out.println("Both are equal");
        }
    }


}
