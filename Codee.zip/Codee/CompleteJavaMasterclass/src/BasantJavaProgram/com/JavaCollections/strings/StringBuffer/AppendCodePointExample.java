package BasantJavaProgram.com.JavaCollections.strings.StringBuffer;

// Java program to illustrate the
// java.lang.StringBuffer.appendCodePoint(int cp)

public class AppendCodePointExample {

    public static void main(String[] args) {

        StringBuffer sbf = new StringBuffer("Geeksforgeeks");
        System.out.println("Strings buffer = " + sbf);

        // Here it appends the CodePoint as
        // Strings to the string buffer
        sbf.appendCodePoint(65);
        System.out.println("After appending CodePoint is = " + sbf);
    }
}
