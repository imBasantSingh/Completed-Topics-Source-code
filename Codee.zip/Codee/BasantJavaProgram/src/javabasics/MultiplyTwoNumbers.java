package javabasics;

import java.util.Scanner;

public class MultiplyTwoNumbers {

private static Scanner st = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
	System.out.println("Enter First number: ");
	double number1 = st.nextDouble();
	
	System.out.println("Enter Second number: ");
	double number2 = st.nextDouble();
	
	st.close();
	
	double Multiply = number1 * number2;
	
	System.out.println("Multiplication of numbers is "+Multiply);

	}
}
