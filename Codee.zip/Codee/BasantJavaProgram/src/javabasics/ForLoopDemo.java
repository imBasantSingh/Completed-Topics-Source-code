package javabasics;

import java.util.Scanner;

/* 
* Note: BigDecimal is preferred while dealing with high-precision arithmetic
* or situations that require more granular control over rounding off calculations.
*
*/

public class ForLoopDemo {

	public static void main(String[] args) {
		
		Scanner inpt = new Scanner(System.in);
		
		System.out.println("Enter the maximum number");
		double max = inpt.nextDouble();
		
		System.out.println("Enter the minimum number");
		double min = inpt.nextDouble();
		
		System.out.println("Enter the increment by(step)");
		double step = inpt.nextDouble();
		
		for(double i=min;i <= max ;i+=step) {
			
			System.out.println(i);

			
		}
		
	}

}