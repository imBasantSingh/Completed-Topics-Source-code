package com.inputoutput.bufferedreader;

import java.io.*;

public class AcceptFloat {

    public static void main(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //Ask for integer and read it
        System.out.println("Enter the Floating point number : ");
        float num = Float.parseFloat(br.readLine());
        System.out.println("Float you have entered is " + num);
    }
}


