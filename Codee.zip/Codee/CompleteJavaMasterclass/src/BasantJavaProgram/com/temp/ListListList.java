package BasantJavaProgram.com.temp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListListList {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("1");
        list.add("2");
        list.add(1, "3");
        list.remove(2);
        List linkedlist = new LinkedList(list);
        list.addAll(linkedlist);
        linkedlist = list.subList(0, 3);
        linkedlist.clear();
        System.out.println(list);
    }
}

