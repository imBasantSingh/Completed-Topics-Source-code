package BasantJavaProgram.com.JavaBasics.inputoutput.bufferedreader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AcceptInteger {
    public static void main(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//Ask for integer and read it
        System.out.println("Enter the integer : ");
        int num = Integer.parseInt(br.readLine());
        System.out.println("Integer you have entered is " + num);
    }
}
