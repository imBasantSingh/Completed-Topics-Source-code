/* Integer arithmetic operations */
package com.variableoperatorsexpressions.operators;

public class IntegerArithematicOperator {

    public static void main(String[] args) {
       int a = 17, b = 5;
       System.out.println("Sum of a and b is " +(a+b));
       System.out.println("Difference of a from b is " +(a-b));
       System.out.println("Product of a from b is " +(a*b));
       System.out.println("Quotient of a/b is " +(a/b));
       System.out.println("Reminder of a/b is " +(a%b));
    }
}
