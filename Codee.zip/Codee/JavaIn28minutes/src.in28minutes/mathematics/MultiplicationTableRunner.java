package mathematics;

public class MultiplicationTableRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  MultiplicationTable multi = new MultiplicationTable();
		//multi.multiplicationTable();
		//multi.multiplicationTable(9);
		  multi.multiplicationTable(9, 9, 20);

	}

}
