package BasantJavaProgram.com.JavaBasics.mathematics;

public class Volume {

    public static void main(String[] args) {
        double width = 0.5, height = 1.0, depth = 0.2;

        System.out.print("Volume of the box (in cubic meter):");
        System.out.println(width * height * depth);
    }

}

