package BasantJavaProgram.com.JavaBasics.variableoperatorsexpressions.enumexamples;

// Java program to demonstrate working of values(),
// ordinal() and valueOf()

public class EnumMethods {
    public static void main(String[] args) {
        // Calling values()
        Color1 arr[] = Color1.values();

        // enum with loop
        for (Color1 col : arr) {
            // Calling ordinal() to find index
            // of color.
            System.out.println(col + " at index "
                    + col.ordinal());
        }

        // Using valueOf(). Returns an object of
        // Color1 with given constant.
        // Uncommenting second line causes exception
        // IllegalArgumentException
        System.out.println(Color1.valueOf("RED"));
        // System.out.println(Color1.valueOf("WHITE"));
    }
}


