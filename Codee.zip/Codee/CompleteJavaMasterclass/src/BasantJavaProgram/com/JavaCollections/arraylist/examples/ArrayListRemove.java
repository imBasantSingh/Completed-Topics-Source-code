package BasantJavaProgram.com.JavaCollections.arraylist.examples;

/*
 * Object remove(int index):
		It deletes the element from the given index from the arraylist.
		It returns an Exception IndexOutOfBoundsException, If index specified is out of range.
 * */

import java.util.ArrayList;

public class ArrayListRemove {
    public static void main(String args[]) {
        ArrayList<String> aList = new ArrayList<String>(5);
        // use add() method to add elements in the list
        aList.add("LEARNING");
        aList.add("JAVA");
        aList.add("ABHIANDROID");
        System.out.println("Strings ArrayList = " + aList);
        //using Remove method
        aList.remove(2);
        System.out.println("ArrayList After Removing Element at index 2= " + aList);
    }
}
