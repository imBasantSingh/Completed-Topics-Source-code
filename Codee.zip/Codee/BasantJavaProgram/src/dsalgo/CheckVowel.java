package dsalgo;

import java.util.Scanner;

public class CheckVowel {
	
	public static Scanner input = new Scanner(System.in);
	
	public static boolean isVowel = false;
	
	public static void main(String args[]) {
		
		System.out.println("Enter Character: ");
		char ch = input.next().charAt(0);
		
		input.close();
		
		switch(ch) {
		
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U': isVowel = true;
		
		}
		
		if(isVowel == true) {
			   System.out.println(ch+" is  a Vowel");
		}
			else {
			   if((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z'))
				System.out.println(ch+" is a Consonant");
			   else
				System.out.println("Input is not an alphabet");		
		}
}
}
