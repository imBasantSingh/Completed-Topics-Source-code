package oops;

public class Book {
	
	int pages;
	int lessons;
	String writer;
	private int noOfCopies;
	
	public Book(String writer) {
		super();
		this.writer = writer;
	}

	public Book(int pages, int lessons, String writer, int noOfCopies) {
		super();
		this.pages = pages;
		this.lessons = lessons;
		this.writer = writer;
		this.noOfCopies = noOfCopies;
	}
	
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	public int getLessons() {
		return lessons;
	}
	public void setLessons(int lessons) {
		this.lessons = lessons;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	
	public void setnoOfCopies(int noOfCopies) {
		if(noOfCopies > 0) {
		this.noOfCopies = noOfCopies;
		}
	}
	
	public int getnoOfCopies() {
		return noOfCopies;
	}
	
	public void increasenoOfCopies(int howmuch) {
		setnoOfCopies(this.noOfCopies + howmuch);
	}
	
	public void decreasenoOfCopies(int howmuch) {
		setnoOfCopies(this.noOfCopies - howmuch);
	}

}
