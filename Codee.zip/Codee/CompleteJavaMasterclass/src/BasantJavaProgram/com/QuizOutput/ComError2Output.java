package BasantJavaProgram.com.QuizOutput;

public class ComError2Output {
    public static void main(String[] args)
    {
        //for(int i = 0; 0; i++) // Error:(6, 24) java: incompatible types: int cannot be converted to boolean
        for(int i = 0; i< 2 ; i++)  // Changing above to this or successful compilation
        {
            System.out.println("Hello");
            break;
        }
    }
}
