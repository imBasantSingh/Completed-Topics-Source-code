package com.variableoperatorsexpressions.datatypes;

public class ByteShortInt {
    public static void main(String args[]) {
        // int has width of 32
        int myIntMinValue = -2_147_483_648;
        int myIntMaxValue = 2_147_483_647;

        //byte has width of 8
        byte myByteMinValue = -128;
        byte myByteMaxValue = 127;

        //short has width of les16
        short myMinShortValue = -32768;
        short myMaxShortValue = 32767;

        //long has width of 64
        long myMinLongValue = -9_223_372_036_854_775_808L;
        long myMaxLongValue = 9_223_372_036_854_775_807L;

        System.out.println("Integer Min Value: " + myIntMinValue);
        System.out.println("Integer Max Value: " + myIntMaxValue);

        System.out.println("Byte Min Value: " + myByteMinValue);
        System.out.println("Byte Max Value: " + myByteMaxValue);

        System.out.println("Short Min Value: " + myMinShortValue);
        System.out.println("Short Max Value: " + myMaxShortValue);

        System.out.println("Long Min Value: " + myMinLongValue);
        System.out.println("Long Max Value: " + myMaxLongValue);

    }
}
