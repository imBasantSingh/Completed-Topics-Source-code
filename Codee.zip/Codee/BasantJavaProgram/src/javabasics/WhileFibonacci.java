package javabasics;

import java.util.Scanner;

public class WhileFibonacci {
	
	private static Scanner inpt = new Scanner(System.in);

	public static void main(String[] args) {
	
		
		System.out.println("Enter number of fibonacci series: ");
		int count = inpt.nextInt();
		int fibo1 = 0;
		int fibo2 = 1;
		int sumofFibos = 0;
		
		int i = 1;
		while(i<=count) {
			System.out.print(fibo1+" ");
			sumofFibos = fibo1 + fibo2;
			fibo1 = fibo2;
			fibo2 = sumofFibos;
			i++;
		}
	}
	
}

