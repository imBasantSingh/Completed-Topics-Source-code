package com.arrays.examples;

//A sample Java program to sort an array of integers 
//using Arrays.sort(). It by default sorts in 
//ascending order 

/*
 * public static void sort(int[] arr, int from_Index, int to_Index)
		arr - the array to be sorted
		from_Index - the index of the first element, inclusive, to be sorted
		to_Index - the index of the last element, exclusive, to be sorted
   This method doesn't return any value.
 * */
import java.util.Arrays; 

public class SortExample 
{ 
	public static void main(String[] args) 
    { 
        // Our arr contains 8 elements 
        int[] arr = {13, 7, 6, 45, 21, 9, 2, 100}; 
  
        /* Sort subarray from index 1 to 4, i.e., 
           only sort subarray {7, 6, 45, 21} and 
           keep other elements as it is. 
           Arrays.sort(arr, 1, 5); 
        */
  
        System.out.printf("Modified arr[] : %s", Arrays.toString(arr)); 
    } 
}