package BasantJavaProgram.com.JavaCollections.linkedlist.examples;

/*
 * int indexOf(Object o):
		This method gives the index of the element as mentioned in the arraylist starting from zero 
		position
		It will return -1 , if that element is not present in the arraylist.
 * */

import java.util.ArrayList;

public class ArrayListIndexOf {
    public static void main(String args[]) {
        ArrayList<String> aList = new ArrayList<String>(5);
        // use add() method to add elements in the list
        aList.add("Learning");
        aList.add("JAVA");
        aList.add("ABHIANDROID");
        System.out.println("Array List Strings = " + aList);
        // using IndexOf Method
        int value1 = aList.indexOf("JAVA");
        System.out.println("Index Retrived of JAVA = " + value1);
        System.out.println("AT is not present so it will print index as -1");
        int value2 = aList.indexOf("AT");
        System.out.println("Index Retrived of AT = " + value2);
    }
}





