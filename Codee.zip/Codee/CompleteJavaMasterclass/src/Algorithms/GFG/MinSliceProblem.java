package Algorithms.GFG;

public class MinSliceProblem {

    public static void main(String args[]) {

        int[] arr = {13, -7, -6, 45, 21, 9, 2, -100};

        System.out.println("The Min slice is " + solution(arr));

        double Min = Math.min(2, 6);
        System.out.println(Min);
    }

    public static int solution(int[] A) {
        int Min = A[0];
        int MinTemp = A[0];
        int Sum = 0;
        int arr = 0;

        for (int i = 1; i < A.length; i++) {
            arr = A[i];
            Sum = MinTemp + arr;
            MinTemp = Math.min(A[i], Sum);
            Min = Math.min(Min, MinTemp);
        }
        return Min;
    }
}



