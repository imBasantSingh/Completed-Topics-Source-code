package Algorithms.ControlStatements;

/*Write a method called printNumberInWord. The method has one parameter number which is the whole number. The method needs to print "ZERO", "ONE", "TWO", ... "NINE", "OTHER" if the int parameter number is 0, 1, 2, .... 9 or other for any other number including negative numbers. You can use if-else statement or switch statement whatever is easier for you.


        NOTE: Method printNumberInWord needs to be public static for now, we are only using static methods.

        NOTE: Do not add main method to solution code.*/

public class NumberInWord {
    public static void printNumberInWord(int digit) {

        // Switch block to check for each digit c
        switch (digit) {

            // For digit 0
            case 0:
                System.out.print("ZERO");
                break;

            // For digit 1
            case 1:
                System.out.print("ONE");
                break;

            // For digit 2
            case 2:
                System.out.print("TWO");
                break;

            // For digit 3
            case 3:
                System.out.print("THREE");
                break;

            // For digit 4
            case 4:
                System.out.print("FOUR");
                break;

            // For digit 5
            case 5:
                System.out.print("FIVE");
                break;

            // For digit 6
            case 6:
                System.out.print("SIX");
                break;

            // For digit 7
            case 7:
                System.out.print("SEVEN");
                break;

            // For digit 8
            case 8:
                System.out.print("EIGHT");
                break;

            // For digit 9
            case 9:
                System.out.print("NINE");
                break;

            default:
                System.out.print("OTHER");
                break;
        }
    }

    // Driver code
    public static void main(String[] args) {
        printNumberInWord(4);
    }
}


