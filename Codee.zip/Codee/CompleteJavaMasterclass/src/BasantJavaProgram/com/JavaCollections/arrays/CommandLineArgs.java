package BasantJavaProgram.com.JavaCollections.arrays;

//Addition
class CommandLineArgs {
    public static void main(String args[]) {
//check if 2 args are not entered come out.
        if (args.length != 2) {
            System.out.println("Please enter values");
            return;
        }
//take the numbers from args
//they would be in string form
        String s1 = args[0];
        String s2 = args[1];

        //convert them into numeric
        double d1 = Double.parseDouble(s1);
        double d2 = Double.parseDouble(s2);
        //add them and display
        double d3 = d1 + d2;
        System.out.println("The sum= " + d3);
    }
}