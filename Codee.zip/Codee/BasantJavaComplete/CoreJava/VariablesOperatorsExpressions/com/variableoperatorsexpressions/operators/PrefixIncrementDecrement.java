/* Program to understand the floating point arithmetic operation */
package com.variableoperatorsexpressions.operators;

public class PrefixIncrementDecrement {

    public static void main(String[] args) {
       
       int x=8;
       System.out.printf("x=%d\t",x);
       System.out.println();
       System.out.printf("x=%d\t",++x); /*Prefix increment*/
       System.out.println();
       System.out.printf("x=%d\t",x);
       System.out.println();
       System.out.printf("x=%d\t",--x); /*Prefix decrement*/
       System.out.println();
       System.out.printf("x=%d\n",x);
       System.out.println();
       
    }
}
