
public enum JavaDemo {

}
