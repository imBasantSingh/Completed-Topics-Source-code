package com.bitwiseoperators;

//Using bitwise operators
public class Bits{
	
   public static void main(String args[]){
	   
   byte x,y;
   x = 10 ;
   y = 11;
   
   System.out.println("-x= " + (-x) ) ;
   System.out.println("x&y" + (x&y)) ;
   System.out.println("x|y " + (x|y));
   System.out.println("X^Y = " + (x^y)) ;
   System.out.println("x<<2= " + (x<<2)) ;
   System.out.println("x>>2= "+ (x>>2)) ;
   System.out.println("x>>>2= "+ (x>>>2));

//Conditional operator or ternary operator
    int max,a =6, b=9 ;
	max = (a>b)?a:b ;
		System.out.println("Maximum number between a and b is "+ max);
	} 
}