package BasantJavaProgram.com.JavaBasics.variableoperatorsexpressions.variables_datatypes;

public class IntDemo {
    public static void main(String[] args) {

        System.out.println("HelloWorld Basant!");

        int myFirstNumber = (10 + 5) + (2 * 10);
        int mySecondNumber = 12;
        int myThirdNumber = myFirstNumber * 2;

        int myTotal = myFirstNumber + mySecondNumber + myThirdNumber;

        int myLastOne = 1000 - myTotal;

        System.out.println(myLastOne);
    }
}
