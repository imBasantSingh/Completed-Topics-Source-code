package BasantJavaProgram.com.JavaObjectOrientedProgramming.encapsulation;

public class EnhancedPlayerMain {

    public static void main(String[] args) {

        EnhancedPlayer player = new EnhancedPlayer("Tim", 200, "Sword");
        System.out.println("Initial health is " + player.getHealth());
    }
}
