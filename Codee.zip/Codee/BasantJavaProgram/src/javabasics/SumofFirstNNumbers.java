package javabasics;

import java.util.Scanner;

public class SumofFirstNNumbers {
	
	private static Scanner inpt = new Scanner(System.in);

	public static void main(String[] args) {
		int sum =0;
		
		System.out.println("Enter number: ");
		int N = inpt.nextInt();
		
		//Sum of N natural number
		for(int i=1; i<=N;i++) {
			sum+=i;
		}
		
		System.out.println("Sum of first "+N+" natural number is: "+sum);
	}

}
