package oops;

public class MoterBike {
	//State
	private int speed;
	
	//Behavior 
	void start(String name) {
		System.out.println( name +" Bike Started");
	}
	
	public MoterBike(int speed) {
		if(speed > 0) {
			this.speed = speed;
	}
	}
	
	public MoterBike() {
		this(10);
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		if(speed > 0) {
		this.speed = speed;
	}
	}
	
	public void increaseSpped(int howMuch) {
		setSpeed(this.speed = this.speed + howMuch);
	}
	
	public void decreaseSpped(int howMuch) {
		setSpeed(this.speed = this.speed - howMuch);
	}
}
