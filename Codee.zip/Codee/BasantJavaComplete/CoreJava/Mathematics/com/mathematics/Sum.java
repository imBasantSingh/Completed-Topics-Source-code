package com.mathematics;

public class Sum {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		//variables
			int x,y;
		//store values into variables
			x = 10;
			y = 25;
		//calculate sum and store result into z
			int z = x+y;
		//display result
			System.out.print("Sum of number X and Y is "+z);
	}

}
