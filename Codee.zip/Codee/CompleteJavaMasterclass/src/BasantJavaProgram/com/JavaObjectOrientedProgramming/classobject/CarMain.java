package BasantJavaProgram.com.JavaObjectOrientedProgramming.classobject;

public class CarMain {

    public static void main(String[] args) {
        Car porsche = new Car();
        Car holden = new Car();
        porsche.setModel("911");
        holden.setModel("carrera");
        System.out.println("Model is " + porsche.getModel());
        System.out.println("Model is " + holden.getModel());
    }
}
