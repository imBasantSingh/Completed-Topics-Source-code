package BasantJavaProgram.com.JavaFlowControl.Iterativestatements;

public class DemoForEach {
    public static void main(String args[]) {
        int arr[] = {5, 76, -7, 90, 34};
        for (int i : arr) {
            System.out.print(i + "\t");
        }
    }
}
