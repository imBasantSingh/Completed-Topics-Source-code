/* Display Binary in other number systems */
package com.booleanoperators;

public class IntegerToBinaryString {
public static void main(String args[]){
	int num = 0b1010 ; //Binary
	
	System.out.println("");
	System.out.printf("In Decimal = %d", num);
	System.out.println("");
	System.out.printf("In Octal = %o", num);
	System.out.println("");
	System.out.printf("In Hexadecimal = %x", num);
	System.out.println("");
	System.out.printf("In Binary = %s", Integer.toBinaryString(num));
	
   }
}
