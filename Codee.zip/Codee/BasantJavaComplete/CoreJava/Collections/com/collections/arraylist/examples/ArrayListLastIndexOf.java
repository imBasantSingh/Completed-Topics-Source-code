package com.collections.arraylist.examples;

/*
 * int lastIndexOf(Object o):
		This method gives the index of the element as mentioned in the arraylist starting from last 
		position
		It will return -1 , if that element is not present in the arraylist.
 * */

import java.util.ArrayList;

public class ArrayListLastIndexOf {
	public static void main(String args[]) {
		ArrayList<String> aList = new ArrayList<String>(5);
		// use add() method to add elements in the list
		aList.add("A");
		aList.add("B");
		aList.add("C");
		aList.add("D");
		aList.add("E");
		aList.add("F");
		aList.add("C");
		aList.add("D");
		System.out.println("ArrayList: "+aList);
		//Getting index of Last C in ArrayList
		int index1 = aList.lastIndexOf("C");
		System.out.println("index of Last C in ArrayList: " + index1);
		int index2 = aList.lastIndexOf("D");
		System.out.println("index of Last D in ArrayList: " + index2);
	}
}





