/* Program to understand the floating point arithmetic operation */
package com.variableoperatorsexpressions.operators;

public class FloatArithematicOperator {

    public static void main(String[] args) {
       float a = 17.87f , b = 5.11f;
       System.out.println("Sum of a and b is " +(a+b));
       System.out.println("Difference of a from b is " +(a-b));
       System.out.println("Product of a from b is " +(a*b));
       System.out.println("Quotient of a/b is " +(a/b));
       System.out.println("Reminder of a/b is " +(a%b));
    }
}
