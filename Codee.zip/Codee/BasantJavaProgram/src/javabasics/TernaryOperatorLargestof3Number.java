package javabasics;

import java.util.Scanner;

public class TernaryOperatorLargestof3Number {
	
	private static Scanner inpt = new Scanner(System.in);
		
	public static void main(String args[]) {
		
		int temp = 0;
		int result = 0;
		
		System.out.println("Enter the number: ");
		int num1 = inpt.nextInt();
		
		System.out.println("Enter the number: ");
		int num2 = inpt.nextInt();
		
		System.out.println("Enter the number: ");
		int num3 = inpt.nextInt();
		
		temp = (num1 > num2 )? num1 : num2;
		
		result = (temp > num3 )? temp : num3;
		
		System.out.println("Lagest of three number is  : "+result);
  }
}