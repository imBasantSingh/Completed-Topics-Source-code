package com.variableoperatorsexpressions.datatypes;

public class IntegerDemo {
    public static void main(String args[]) {
        System.out.println("##############################");
        System.out.println("Variable Example");
        System.out.println("##############################");

        //variable declaration
        int myFirstNumber = 5;
        int mySecondNumber = 12;
        int Total = myFirstNumber + mySecondNumber;
        System.out.println("myFirstNumber is " + myFirstNumber);
        System.out.println("mySecondNumber is " + mySecondNumber);
        System.out.println("Total is " + Total);
    }
}
