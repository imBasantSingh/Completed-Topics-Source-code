package BasantJavaProgram.com.JavaCollections.arrays;

//Command line arguments
class CmdLineArgs {
    public static void main(String args[]) {
/*
//find number or arguments
		int n = args.length;
		System.out.println("No. of args= "+ n);
//display all the arguments
		System.out.println("The args are: ");
		for(int i=0; i<n; i++)
			System.out.println(args[i]);
*/

        System.out.println("No. of args= " + args.length);
        //display all the arguments
        System.out.println("The args are: ");
        for (int i = 0; i < args.length; i++)
            System.out.println(args[i]);
    }
}
