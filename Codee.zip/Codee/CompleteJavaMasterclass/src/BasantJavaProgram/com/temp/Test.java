package BasantJavaProgram.com.temp;

class Testc {
    public static void main(String args[])
    {
        int t;
       // System.out.println(t); // Compilation Error:(7, 28) java: variable t might not have been initialized

        t = 20;
        System.out.println(t);
    }
}



