package BasantJavaProgram.com.JavaFlowControl.Iterativestatements;

public class DemoNestedForLoop {
    public static void main(String agrs[]) {
        int i = 1, j;
        lp1:
        while (i <= 3) {
            System.out.print(i); // i values changes from 1 to 3
            lp3:
            for (j = 1; j <= 5; j++) {
                System.out.println("  " + j);
            }
            i++;
            System.out.println("*************");
        }
    }

}
