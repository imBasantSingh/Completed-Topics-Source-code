package com.InputOutput.scannerIO;

import java.util.Scanner;

public class ScannerInput {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        //Unexpected result
        System.out.println("Enter the name: ");
        String name = sc.next();
        System.out.println("Enter the ID: ");
        int id = sc.nextInt();
        System.out.println("Enter Sex:(M/F) ");
        char ch = sc.next().charAt(0);
        System.out.println("Enter the Salary: ");
        float salary = sc.nextFloat();
        System.out.print("#####   Employee Details  #####");
        System.out.print("Employee name : " + name);
        System.out.print("Employee ID : " + id);
        System.out.print("Sex " + ch);
        System.out.print("Employee Salary : " + salary);
    }
}
