package com.collections.linkedlist.examples;

/*
 * int size():
		This method returns the size of the arraylist.
		size() methods start count with 1 not 0.

 * */
import java.util.ArrayList;

public class ArrayListSize {
	public static void main(String[] args) {
		ArrayList<Integer> aList = new ArrayList<Integer>();
		aList.add(1);
		aList.add(2);
		aList.add(3);
		aList.add(4);
		aList.add(5);
		aList.add(6);
		// Using size Method
		System.out.println("Size of Arraylist is :" + aList.size());
	}
}
