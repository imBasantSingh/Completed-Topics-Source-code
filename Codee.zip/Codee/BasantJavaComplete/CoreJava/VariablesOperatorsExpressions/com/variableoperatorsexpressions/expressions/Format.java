package com.variableoperatorsexpressions.expressions;

public class Format {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=1,b=2,c=3,d=4;
		System.out.print(a+"\t"+b);
		System.out.println(b+"\n"+b);
		System.out.print(":"+c);
		System.out.println(); //this throws cursor to the next line
		System.out.println("Hello "+d);

	}

}
