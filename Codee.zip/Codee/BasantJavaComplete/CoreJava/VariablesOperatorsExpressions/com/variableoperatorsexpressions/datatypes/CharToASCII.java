package com.variableoperatorsexpressions.datatypes;

public class CharToASCII {

	public static void main(String[] args) {
		
		char ch = 'A';
		
		int asciiCode = (int)ch;
		
		System.out.println(asciiCode);

	}

}
