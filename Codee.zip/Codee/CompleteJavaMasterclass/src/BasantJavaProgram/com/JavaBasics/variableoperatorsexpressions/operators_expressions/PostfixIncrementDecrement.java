/* Program to understand the floating point arithmetic operation */
package BasantJavaProgram.com.JavaBasics.variableoperatorsexpressions.operators_expressions;

public class PostfixIncrementDecrement {

    public static void main(String[] args) {

        int x = 8;
        System.out.printf("x=%d\t", x);
        System.out.println();
        System.out.printf("x=%d\t", x++); /*Postfix increment*/
        System.out.println();
        System.out.printf("x=%d\t", x);
        System.out.println();
        System.out.printf("x=%d\t", x--); /*Postfix decrement*/
        System.out.println();
        System.out.printf("x=%d\n", x);
        System.out.println();

    }
}
