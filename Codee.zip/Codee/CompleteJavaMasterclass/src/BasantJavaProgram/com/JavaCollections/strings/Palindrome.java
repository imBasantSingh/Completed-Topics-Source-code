package BasantJavaProgram.com.JavaCollections.strings;

//Palindrome or not

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Palindrome {
    public static void main(String args[]) throws IOException {
//accept the string from keyboard
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter a string: ");
        String str = br.readLine();
//store a copy of original string in temp
        String temp = str;
//convert the string into StringBuffer
        StringBuffer sb = new StringBuffer(str);
//now reverse the string in StringBuffer
        sb.reverse();
//convert the StringBuffer into a string
        str = sb.toString();
//compare the original string available in
//temp with this reversed string
        if (temp.equalsIgnoreCase(str))
            System.out.println(temp + " is Palindrome");
        else System.out.println(temp + " is not a palindrome");
    }
}
