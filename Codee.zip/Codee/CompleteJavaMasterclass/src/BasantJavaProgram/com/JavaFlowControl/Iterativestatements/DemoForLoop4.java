package BasantJavaProgram.com.JavaFlowControl.Iterativestatements;

public class DemoForLoop4 {
    public static void main(String args[]) {
        //Infinite loop
        for (int i = 0; i <= 10 + i; i++)
            System.out.print(i + " ");
    }

}
