package BasantJavaProgram.com.JavaBasics.introduction;

/**
 * Created by Basant_Kumar_Singh
 */

public class HelloWorld {

    // Your program begins with a call to main().
    // Prints "Hello, World" to the terminal window.

    public static void main(String... args) {

        System.out.println();
        System.out.println("Hello... Java Programmers! ");
        System.out.println("This is our first Java Program! ");

    }
}
