package javabasics;

import java.util.Scanner;

public class TernaryOperatorCheckIfPositive {
	
	private static Scanner inpt = new Scanner(System.in);
	
	public static void main(String args[]) {
		
		System.out.println("Enter the number: ");
		int number1 = inpt.nextInt();
		
		String result = (number1 < 0)? "Negative" : "Not Negative";
		
		System.out.println("Entered number is : "+result);
   
}
}