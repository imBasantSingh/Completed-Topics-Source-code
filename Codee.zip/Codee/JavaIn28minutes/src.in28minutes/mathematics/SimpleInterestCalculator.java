package mathematics;

import java.math.BigDecimal;

public class SimpleInterestCalculator {
	
	BigDecimal Principal;
	BigDecimal Rate;
	public SimpleInterestCalculator(String principal, String rate) {
		super();
		Principal = new BigDecimal(principal);
		Rate = new BigDecimal(rate).divide(new BigDecimal("100"));
	}
	
	BigDecimal calculateTotalValue(String noOfYears){
		BigDecimal NoOfYears = new BigDecimal(noOfYears);
		
		BigDecimal totalValue = Principal.add(Principal.multiply((Rate).multiply(NoOfYears)));
				
	    return totalValue;
		
	}

}


