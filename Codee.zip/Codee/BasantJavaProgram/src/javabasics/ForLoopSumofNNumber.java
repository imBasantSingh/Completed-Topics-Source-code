package javabasics;

import java.util.Scanner;

public class ForLoopSumofNNumber {

private static Scanner st = new Scanner(System.in);
	
	public static void main(String[] args) {
		
	int sum = 0;
	System.out.println("Enter number of integers : ");
	int n = st.nextInt();
	
	for(int i=0; i < n ; i++) {
		int num[] = new int[n];
		System.out.println("Enter number: "+(i+1));
		num[i] = st.nextInt();
		sum+=num[i];
	}
	
    st.close();
			
	System.out.println("Sum of numbers is "+sum);

	}
}
