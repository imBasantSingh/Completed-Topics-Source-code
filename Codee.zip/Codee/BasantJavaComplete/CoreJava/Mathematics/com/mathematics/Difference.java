package com.mathematics;

public class Difference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//variables
			int x,y;
		//store values into variables
			x = 100;
			y = 25;
		//calculate sum and store result into z
			int z = x-y;
		//display result
			System.out.print("Difference of number X - Y is "+z);
	}

}
