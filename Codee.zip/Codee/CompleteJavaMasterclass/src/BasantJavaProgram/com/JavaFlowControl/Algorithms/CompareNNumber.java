package BasantJavaProgram.com.JavaFlowControl.Algorithms;

        /*
         * Program to compare N numbers.
         * */

public class CompareNNumber {

  /*  private static Scanner input = new Scanner(System.in);

    public static void main(Strings[] args) {
        System.out.println("Enter number of elements to compare: ");
        int N = input.nextInt();
        int inputNNumber[] = new int[N];

    }

    public static int[] inputNNumber()*/

}
