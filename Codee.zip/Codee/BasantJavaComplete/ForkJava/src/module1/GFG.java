package module1;

import java.util.*;
import java.lang.*;
import java.io.*;
class GFG{
	public static void main (String[] args){
	 
		Object[][] twoDimArray = {
				{"Tom", -100.678, 44, 'X', true},
				{"Dick", 50.88, 777, 'Y', false},
				{"Harry", -20.4455, 5151, 'Z', false}
		};
		
		for(Object[] oneDimArray : twoDimArray) {
			// System.out.format(formatStr,oneDimArray);
			
		}
	}
	 
}
