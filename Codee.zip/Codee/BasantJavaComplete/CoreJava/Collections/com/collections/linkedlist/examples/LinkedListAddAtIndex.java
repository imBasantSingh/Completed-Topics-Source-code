package com.collections.linkedlist.examples;

/*
 * void add(int index, Object element):
		It adds an element of Specific Object type at the specified index of the LinkedList 
		as given in the argument of the method.
		It does not return anything as its return type is void.
		If in case the index specified is out of range it throws an IndexOutOfBoundsException
 * */

import java.util.LinkedList;

public class LinkedListAddAtIndex {
	public static void main(String[] args) {
		LinkedList<String> llist = new LinkedList<String>();
		llist.add("Hi");
		llist.add("I");
		llist.add("Love");
		llist.add("java");
		System.out.println("LinkedList:" + llist);
		//Using Add method at specific index
		llist.add(1,"Element");
		System.out.println("Linked List:" + llist);
		}
}





