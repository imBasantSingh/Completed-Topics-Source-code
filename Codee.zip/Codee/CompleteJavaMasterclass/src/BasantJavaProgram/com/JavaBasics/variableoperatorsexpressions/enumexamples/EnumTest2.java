package BasantJavaProgram.com.JavaBasics.variableoperatorsexpressions.enumexamples;

// enum declaration inside a class.
public class EnumTest2 {
    enum Color {
        RED, GREEN, BLUE;
    }
    /* internally above enum Color1 is converted to
class Color1
{
     public static final Color1 RED = new Color1();
     public static final Color1 BLUE = new Color1();
     public static final Color1 GREEN = new Color1();
}*/


    // Driver method
    public static void main(String[] args) {
        Color c1 = Color.BLUE;
        System.out.println(c1);
    }
}


