package oops;

public class Website {
	private String webName;
	private int webAge;
	
	// constructor
	   Website(String name, int age){
	      this.webName = name;
	      this.webAge = age;
	   }
	   
	    
	   public static void main(String args[]) {
		      //Creating objects
		      Website Beginnersbook = new Website("beginnersbook", 5);
		      Website Google = new Website("google", 18);

		     //Accessing object data through reference
		     System.out.println(Beginnersbook.webName+" "+Beginnersbook.webAge);
		     System.out.println(Google.webName+" "+Google.webAge);
	   }
}
