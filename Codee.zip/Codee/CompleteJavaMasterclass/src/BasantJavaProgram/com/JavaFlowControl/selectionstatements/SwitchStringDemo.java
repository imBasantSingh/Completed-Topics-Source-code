//Switch supporting String type
package BasantJavaProgram.com.JavaFlowControl.selectionstatements;

public class SwitchStringDemo {
    public static void main(String args[]) {
        String day = "Tue";
        switch (day) {
            case "Sun":
                System.out.println("Sunday");
                break;
            case "Mon":
                System.out.println("Monday");
                break;
            case "Tue":
                System.out.println("Tuesday");
                break;
            case "Wed":
                System.out.println("Wednusday");
                break;
            case "Thu":
                System.out.println("Thusday");
                break;
            case "Fri":
                System.out.println("Friday");
                break;
            case "Sat":
                System.out.println("Satarday");
                break;
            default:
                System.out.println("Wrong Day");
                break;
        }
    }

}
