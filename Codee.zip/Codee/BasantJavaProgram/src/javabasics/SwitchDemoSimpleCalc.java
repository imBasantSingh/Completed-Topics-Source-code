package javabasics;

import java.util.Scanner;
public class SwitchDemoSimpleCalc {
	private static Scanner inpt = new Scanner(System.in);

	public static void main(String[] args) {
		
		int result = 0;
		
		System.out.println("Enter the first number: ");
		int num1 = inpt.nextInt();
		
		System.out.println("Enter the second number: ");
		int num2 = inpt.nextInt();
		
		System.out.println("Enter the Operation(+,-,*,/,%): ");
		char op = inpt.next().charAt(0);
		
		
		switch(op) {
		
		case '+':{
			result = num1+num2;
			System.out.println("Result is: "+result);
			break;
		}
		
		case '-':{
			result = num1-num2;
			System.out.println("Result is: "+result);
			break;
		}
		case '/':{
			result = num1/num2;
			System.out.println("Result is: "+result);
			break;
		}
		case '%':{
			result = num1%num2;
			System.out.println("Result is: "+result);
			break;
		}
		default : 
			System.out.println("Please enter valid operator");
						
		}

	}

}
