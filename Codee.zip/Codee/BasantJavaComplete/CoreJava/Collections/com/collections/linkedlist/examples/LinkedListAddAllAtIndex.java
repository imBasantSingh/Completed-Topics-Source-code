package com.collections.linkedlist.examples;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

/*
 * boolean addAll(int index, Collection c):
		This methods add each element of the Specific collection type at the specified index as 
		mentioned in the argument
		It returns true if collection is successfully added, and returns false if it is not.
		If the collection passed in as an argument is null then it throws Null Pointer Exception.
 * */



public class LinkedListAddAllAtIndex {
	public static void main(String[] args) {
		LinkedList<String> llist = new LinkedList<String>();
		llist.add("Hi");
		llist.add("I");
		llist.add("Love");
		llist.add("java");
		System.out.println("Linked List:" + llist);
		Collection<String> collection = new ArrayList<String>();
		collection.add("I");
		collection.add("Love");
		collection.add("Android");
		// using method addAll() at index 3
		llist.addAll(3,collection);
		System.out.println("Linked List:" + llist);
		}
}





