package oops;

public class BookRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book cleanCode = new Book(876,22,"Basant Singh",6);
		Book artOfComputerProgramming = new Book(876,24,"Kajal Singh",6);
		Book effectiveJava = new Book(876,20,"Anant Singh",14);
		
		cleanCode.setPages(800);
		artOfComputerProgramming.setPages(900);
		effectiveJava.setPages(1000);
		
		//cleanCode.noOfCopies = 100;
		//artOfComputerProgramming.noOfCopies = 50;
		//effectiveJava.noOfCopies = 45;
		
		cleanCode.setnoOfCopies(2);
		System.out.println(cleanCode.getnoOfCopies());
		
		cleanCode.increasenoOfCopies(2);
		System.out.println(cleanCode.getnoOfCopies());
		
		cleanCode.decreasenoOfCopies(6);
		System.out.println(cleanCode.getnoOfCopies());
		
		cleanCode.decreasenoOfCopies(2);
		System.out.println(cleanCode.getnoOfCopies());
		
	}

}
