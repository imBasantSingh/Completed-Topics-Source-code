package javabasics;

import java.util.Scanner;

public class SumofTwoNumber {

private static Scanner st = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
	System.out.println("Enter First number: ");
	int number1 = st.nextInt();
	
	System.out.println("Enter Second number: ");
	int number2 = st.nextInt();
	
	st.close();
	
	int sum = number1 + number2;
	
	System.out.println("Sum of numbers is "+sum);

	}
}
