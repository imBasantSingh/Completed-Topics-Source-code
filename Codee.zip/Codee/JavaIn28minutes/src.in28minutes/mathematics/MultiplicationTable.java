package mathematics;

public class MultiplicationTable {
	
	public void multiplicationTable() {
		multiplicationTable(5);
	}
	
	public void multiplicationTable(int table) {
		multiplicationTable(table,1,10);
	}
	
	public void multiplicationTable(int table, int to, int from) {
		for(int i=to;i<=from;i++) {
		System.out.printf("%d * %d = %d", table, i, table*i).println();
	}
	}

}
