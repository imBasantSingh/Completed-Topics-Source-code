package com.inputoutput.scannerio;

import java.util.Scanner;

public class InputTest{

//public static Scanner input = new Scanner(System.in); 

public static void main(String a[]){
		System.out.println("Enter integer: ");
		
		Scanner input = new Scanner(System.in); 
		
		int num = input.nextInt();
		
		input.close();
		
		System.out.println("Integer is "+num);
}

}
