package BasantJavaProgram.com.JavaBasics.variableoperatorsexpressions.operators_expressions;

public class TernaryOp {

    public static void main(String[] args) {

        boolean isCar = true;
        boolean wasCar = isCar ? true : false;
        if (wasCar) {
            System.out.println("wasCar is true");
        }
    }
}
