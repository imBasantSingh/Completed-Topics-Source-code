package BasantJavaProgram.com.JavaBasics.variableoperatorsexpressions.enumexamples;

// A Java program to demonstrate that we can have
// main() inside enum class.
enum ColorDemo
{
    RED, GREEN, BLUE;

    // Driver method
    public static void main(String[] args)
    {
        ColorDemo c1 = ColorDemo.RED;
        System.out.println(c1);
    }
}

