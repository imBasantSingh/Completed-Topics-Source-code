package BasantJavaProgram.com.JavaClassObjects;

public class PersonDemo {
    String name;
    int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name!=null && name.length()>2)
        this.name = name;
        else this.name = "Invalid Name";
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
