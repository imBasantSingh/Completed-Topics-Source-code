package com.Introduction;

/**
 * Created by Basant
 */
public class Hello {
    public static void main(String[] args) {
        System.out.print("Hello, ");
        System.out.println("Java programmer!");
    }
}
