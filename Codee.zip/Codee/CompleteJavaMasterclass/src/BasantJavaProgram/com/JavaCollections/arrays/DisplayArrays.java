package BasantJavaProgram.com.JavaCollections.arrays;

class DisplayArrays {
    public static void main(String args[]) {
//declare and initialize the array
        int arr[] = {50, 60, 55, 67, 70};
//display all the 5 elements
        for (int i = 0; i < 5; i++) {
            System.out.print(arr[i] + "\t");
        }
    }
}