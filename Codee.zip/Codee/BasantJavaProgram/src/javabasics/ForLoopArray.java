package javabasics;

public class ForLoopArray {

	public static void main(String[] args) {
		
		int arr[] = {222, 21, 6, 5, 9, 101, 62};
		
		for(int i=0; i<arr.length;i++) {
			
			System.out.println(arr[i]);
			
		}
		
		System.out.println("Array Length is: "+arr.length);

	}

}