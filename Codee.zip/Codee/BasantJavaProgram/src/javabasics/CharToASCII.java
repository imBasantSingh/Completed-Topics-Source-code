package javabasics;

import java.util.Scanner;

public class CharToASCII {
	
	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Enter character : ");
		char ch = scan.next().charAt(0);
		
		int asciiCode = ch;
		int asciiValue = (int)ch;
		
		 System.out.println("ASCII value of "+ch+" is: " + asciiCode);
	     System.out.println("ASCII value of "+ch+" is: " + asciiValue);

	}

}
