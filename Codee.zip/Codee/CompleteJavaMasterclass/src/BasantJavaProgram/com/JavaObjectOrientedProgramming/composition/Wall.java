package BasantJavaProgram.com.JavaObjectOrientedProgramming.composition;

/**
 * Created by dev on 16/07/15.
 */
public class Wall {
    private String direction;

    public Wall(String direction) {
        this.direction = direction;
    }

    public String getDirection() {
        return direction;
    }
}
