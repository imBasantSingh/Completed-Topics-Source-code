package BasantJavaProgram.com.JavaBasics.mathematics;


        /* IMPORTANT: Multiple classes and nested static classes are supported */

//import for Scanner and other utility classes

import java.util.Scanner;
//Warning: Printing unwanted or ill-formatted data to output will cause the test cases to fail

public class FactorialTestClass {

    public static void main(String args[]) throws Exception {

        Scanner input = new Scanner(System.in);

        int num = input.nextInt();
        input.close();


        // Write your code here
        long fact = 1;

        if (num == 0 || num == 1)
            fact = 1;

        for (int i = 2; i <= num; i++) {
            fact = fact * i;
        }
        System.out.println(fact);
    }
}
