package com.controlstatements.selectionstatements;

public class DemoReturn {
	
public static void main(String args[]){
	int x= 1;
	System.out.println("Before return");
	if(x ==1)
		return; //Terminate the application
	System.out.println("After return");
	}

}
